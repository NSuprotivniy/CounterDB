from django.apps import AppConfig


class CounterlikeConfig(AppConfig):
    name = 'counterlike'
